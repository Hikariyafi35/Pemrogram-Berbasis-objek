package Try;
class MahasiswaAktif extends Mahasiswa {
    public MahasiswaAktif(String nim, String nama, int semester, int usia, String[] krs) {
        super(nim, nama, semester, usia, krs);
    }
}
